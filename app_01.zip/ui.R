library(shiny)
library(leaflet)

ui <- fluidPage(
  
  # Titulo de la app ----
  titlePanel("Mapa de crimenes"),
  
  # Sidebarlayout se define el input y el output ----
  sidebarLayout(
    
    # Sidebarpanel, aqui van los inputs ----
    sidebarPanel(
      
      # Input: Slider para seleccionar año ----
      selectInput(inputId = "Var_YEAR",
                  label = "Año",
                  choices = YEARS ,
                  selected= "2013" ,
                  multiple = FALSE),

      # Input: Slider para seleccionar mes ----
      selectInput(inputId = "Var_MONTH",
                  label = "Mes",
                  choices = MONTHS,
                  selected= "1",
                  multiple = FALSE)
      ),

    # Mainpanel es para mostrar el output ----
    mainPanel(
      # Output: aqui se muestra el mapa generado en el server ----
      leafletOutput("map", height = "800px")
    )
  )
)
