library(leaflet)
library(dplyr)

server <- function(input, output) {
  
  output$map <-renderLeaflet({
    
    df<-crimen_lat_lon %>%
      filter( YEAR==input$Var_YEAR) %>%
      filter( MONTH==input$Var_MONTH) %>%
      leaflet() %>%
            addProviderTiles("OpenStreetMap.BlackAndWhite", options= providerTileOptions(opacity = 0.6)) %>%
            addMarkers(~long, ~lat,
                        clusterOptions = markerClusterOptions()
            )
    
    
  })
  
}


