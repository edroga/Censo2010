library(readr)
library(leaflet)
library(dplyr)

crimen_lat_lon<-read_csv("crime-lat-long.csv") %>%
  filter( !is.na(lat) ) %>%
  mutate(YEAR= as.character(year),
         MONTH=as.character(month) )

YEARS<-unique(crimen_lat_lon$YEAR)
MONTHS<-unique(crimen_lat_lon$MONTH)


